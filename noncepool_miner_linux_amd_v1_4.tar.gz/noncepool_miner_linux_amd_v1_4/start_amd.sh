#!/bin/sh
set -x
wallet_address="6de6d1e3b6a49dae98e6a0f5841dc2025ad7d98ace06a5975d5d641e"
worker_name="03"

#if you want to use screen to run your miner in the background
#screen -L -dmS miner noncepool_miner $wallet_address $worker_name

#if you want to skip certain GPUs
#./noncepool_miner --skip-gpu 0,1 $wallet_address $worker_name

#otherwise use this
./noncepool_miner $wallet_address $worker_name


